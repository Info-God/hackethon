export { Register } from "./Register.jsx";
